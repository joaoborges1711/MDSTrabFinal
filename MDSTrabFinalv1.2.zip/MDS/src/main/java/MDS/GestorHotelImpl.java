package MDS;

//import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.fasterxml.jackson.core.type.TypeReference;

import java.util.Date;
//import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

public class GestorHotelImpl {
    public static void main(String[] args) {
        GestorHotel g = new GestorHotel(0, "joao", "123", LocalDate.of(2003, 12, 12));
        List<Quarto> quartosTotais = ArquivoUtil.carregarLista("quartos.json", new TypeReference<List<Quarto>>() {
        });
        List<Reserva> reservasPendentes = ArquivoUtil.carregarLista("reservasPendentes.json",
                new TypeReference<List<Reserva>>() {
                });

        try {
            Scanner s = new Scanner(System.in);
            int c = 0;
            while (c != 9) {

                System.out.print("\n==============================\n");
                System.out.println("   BEM VINDO AO SISTEMA DE   ");
                System.out.println("      GESTÃO DO HOTEL");
                System.out.print("==============================\n");
                System.out.println("1 - Consultar Quarto");
                System.out.println("2 - Confirmar Reserva");
                System.out.println("3 - Adicionar Manutenção");
                System.out.println("4 - Adicionar Reserva");
                System.out.println("5 - Listar Quartos");
                System.out.println("6 - Remover Manutenção");
                System.out.println("9 - SAIR\n");
                System.out.print("Escolha uma operação: ");
                c = s.nextInt();
                System.out.println();

                switch (c) {
                    case 1:
                        System.out.print("ID do Quarto: ");
                        int idQuarto = s.nextInt();
                        Quarto q = g.consultarQuarto(idQuarto, quartosTotais);
                        if (q == null) {
                            System.out.println("Esse quarto não existe");
                        } else {
                            System.out.println(q);
                        }
                        break;

                    case 2:
                        System.out.println("Lista das reservas pendentes:");
                        for (Reserva r : reservasPendentes) {
                            System.out.println(r);
                        }
                        System.out.print("Digite o ID da reserva que pretende confirmar: ");
                        int idReservaConfirmar = s.nextInt();

                        Reserva reservaConfirmada = null;

                        for (Reserva r : reservasPendentes) {
                            if (r.getIdReserva() == idReservaConfirmar) {
                                reservaConfirmada = r;
                                break;
                            }
                        }

                        if (reservaConfirmada == null) {
                            System.out.println("Reserva não encontrada");
                            break;
                        }

                        try {

                            List<Quarto> quartos = ArquivoUtil.carregarLista("quartos.json",
                                    new TypeReference<List<Quarto>>() {
                                    });

                            Quarto quartoReservado = null;
                            for (Quarto room1 : quartos) {
                                if (room1.getId() == reservaConfirmada.getIdQuarto()) {
                                    quartoReservado = room1;
                                    break;
                                }
                            }

                            if (quartoReservado == null) {
                                System.out.println("erro: Quarto associado à reserva não encontrado");
                                break;
                            }

                            reservaConfirmada.alterarStatus("confirmada");
                            reservaConfirmada.setId(quartoReservado.getReservas().size() + 1);
                            quartoReservado.getReservas().add(reservaConfirmada);

                            reservasPendentes.remove(reservaConfirmada);

                            ArquivoUtil.guardarLista("quartos.json", quartos);
                            ArquivoUtil.guardarLista("reservasPendentes.json", reservasPendentes);

                            System.out.println("Reserva confirmada com sucesso: " + reservaConfirmada);
                        } catch (Exception e) {
                            System.out.println("Erro ao confirmar reserva: " + e.getMessage());
                        }
                        break;

                    case 3:
                        System.out.println("Detalhes da Manutenção:");
                        System.out.print("ID do Quarto: ");
                        idQuarto = s.nextInt();
                        System.out.print("Tipo de Manutenção: ");
                        s.nextLine();
                        String tipoManutencao = s.nextLine().trim();

                        if (tipoManutencao.isEmpty()) {
                            System.out.println("tipo de manutenção não pode ser vazio");
                            break;
                        }

                        try {

                            List<Quarto> quartos = ArquivoUtil.carregarLista("quartos.json",
                                    new TypeReference<List<Quarto>>() {
                                    });

                            Quarto quarto = null;
                            for (Quarto room : quartos) {
                                if (room.getId() == idQuarto) {
                                    quarto = room;
                                    break;
                                }
                            }

                            if (quarto == null) {
                                System.out.println("Quarto não encontrado");
                            } else {

                                Manutencao manutencao = new Manutencao(quarto.getManutencoes().size() + 1,
                                        tipoManutencao);
                                quarto.getManutencoes().add(manutencao);

                                // Alterar o status do quarto para "em manutenção", se não estiver já em
                                // manutenção
                                /*
                                 * if (!"em manutenção".equals(quarto.getStatus())) {
                                 * quarto.setStatus("em manutenção");
                                 * }
                                 */

                                ArquivoUtil.guardarLista("quartos.json", quartos);
                                System.out.println("manutenção adicionada com sucesso: " + manutencao);
                            }
                        } catch (Exception e) {
                            System.out.println("erro ao adicionar manutenção: " + e.getMessage());
                        }
                        break;

                    case 4:
                        System.out.println("Adicionar Reserva:");
                        System.out.print("ID do Quarto: ");
                        idQuarto = s.nextInt();
                        System.out.print("Data de Entrada (yyyy-MM-dd): ");
                        String entrada1 = s.next();
                        System.out.print("Data de Saída (yyyy-MM-dd): ");
                        String saida1 = s.next();
                        System.out.println("ID cliente:");
                        int idCliente = s.nextInt();
                        try {
                            // Carregar os quartos do arquivo JSON
                            List<Quarto> quartos = ArquivoUtil.carregarLista("quartos.json",
                                    new TypeReference<List<Quarto>>() {
                                    });

                            // Encontrar o quarto pelo ID
                            Quarto quarto = null;
                            for (Quarto q1 : quartos) {
                                if (q1.getId() == idQuarto) {
                                    quarto = q1;
                                    break;
                                }
                            }

                            if (quarto == null) {
                                System.out.println("Quarto não encontrado");
                            } else {
                                // Verificar disponibilidade dinâmica
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                                Date dataEntrada = sdf.parse(entrada1);
                                Date dataSaida = sdf.parse(saida1);

                                if (!quarto.isDisponivel(dataEntrada, dataSaida)) {
                                    System.out.println("erro: Quarto não está disponível para o período solicitado");
                                } else {
                                    Reserva reserva = new Reserva(quarto.getReservas().size() + 1, dataEntrada,
                                            dataSaida, "confirmada", idQuarto, idCliente);
                                    quarto.getReservas().add(reserva);
                                    ArquivoUtil.guardarLista("quartos.json", quartos);
                                    System.out.println("Reserva adicionada com sucesso: " + reserva);
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("Erro ao adicionar reserva: " + e.getMessage());
                        }
                        break;

                    case 5:
                        System.out.println("Lista de Todos os Quartos:");
                        for (Quarto quarto : quartosTotais) {
                            System.out.println(quarto);
                        }
                        break;

                    case 6:
                        System.out.println("ID do quarto:");
                        int idQ = s.nextInt();
                        System.out.print("ID da Manutenção para Remover: ");
                        int idManutencao = s.nextInt();
                        boolean removido = false;
                        boolean quartoEncontrado = false;

                        for (Quarto quarto : quartosTotais) {
                            if (quarto.getId() == idQ) {
                                quartoEncontrado = true;
                                for (Manutencao m : quarto.getManutencoes()) {
                                    if (m.getIdManutencao() == idManutencao) {
                                        g.removerManutencao(m, quarto.getManutencoes());
                                        System.out.println("Manutenção removida com sucesso");
                                        removido = true;
                                        break;
                                    }
                                }
                                break;
                            }
                        }

                        if (!quartoEncontrado) {
                            System.out.println("quarto não encontrado");
                        } else if (!removido) {
                            System.out.println("manutenção não encontrada");
                        } else {
                            // Salva a lista atualizada de quartos no arquivo JSON
                            try {
                                ArquivoUtil.guardarLista("quartos.json", quartosTotais);
                            } catch (Exception e) {
                                System.out.println("Erro ao guardar as alterações no ficheiro: " + e.getMessage());
                            }
                        }
                        break;

                    case 9:
                        System.out.println("ADEUS");
                        s.close();
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Opção inválida");
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
