package MDS;

//import java.io.File;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;

public class FuncionarioHotelImpl {
    public static void main(String[] args) {
        FuncionarioHotel funcionario = new FuncionarioHotel(1, "Admin", "123456", LocalDate.of(1985, 5, 10));
        Scanner scanner = new Scanner(System.in);
        List<Quarto> quartosTotais = ArquivoUtil.carregarLista("quartos.json", new TypeReference<List<Quarto>>() {});
        List<Reserva> reservasPendentes = ArquivoUtil.carregarLista("reservasPendentes.json", new TypeReference<List<Reserva>>() {});
       // Scanner s = new Scanner(System.in);
        int opcao = 0;
        while (opcao != 9) {
            System.out.print("\n==============================\n");
            System.out.println("     SISTEMA FUNCIONÁRIO");
            System.out.println("==============================");
            System.out.println("1 - Confirmar Reserva");
            System.out.println("2 - Adicionar Manutenção");
            System.out.println("3 - Remover Manutenção");
            System.out.println("4 - Procurar Quarto");
            System.out.println("5 - Cancelar Reserva");
            System.out.println("9 - SAIR");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            System.out.println();

            switch (opcao) {
                case 1:
                if(reservasPendentes.size() == 0){
                    System.out.println("não existem reservas pendentes de confirmação");
                    continue;
                }
                System.out.println("Lista das reservas pendentes:");
                
                for (Reserva r : reservasPendentes) {
                    System.out.println(r);
                }
                System.out.print("Digite o ID da reserva que pretende confirmar: ");
                int idReservaConfirmar = scanner.nextInt();
            
                Reserva reservaConfirmada = null;
            
                for (Reserva r : reservasPendentes) {
                    if (r.getIdReserva() == idReservaConfirmar) {
                        reservaConfirmada = r;
                        break;
                    }
                }
            
                if (reservaConfirmada == null) {
                    System.out.println("Reserva não encontrada");
                    break;
                }
            
                try {
                    List<Quarto> quartos = ArquivoUtil.carregarLista("quartos.json", new TypeReference<List<Quarto>>() {});
                    Quarto quartoReservado = null;
                    for (Quarto room1 : quartos) {
                        if (room1.getId() == reservaConfirmada.getIdQuarto()) {
                            quartoReservado = room1;
                            break;
                        }
                    }
            
                    if (quartoReservado == null) {
                        System.out.println("Erro: Quarto associado à reserva não encontrado");
                        break;
                    }
            
                    // Adicionar a reserva ao quarto e alterar seu status
                    reservaConfirmada.alterarStatus("confirmada");
                    reservaConfirmada.setId(quartoReservado.getReservas().size() + 1);
                    quartoReservado.getReservas().add(reservaConfirmada);
                  //  quartoReservado.setStatus("ocupado");
            
                    // Remover a reserva do arquivo de reservas pendentes
                    reservasPendentes.remove(reservaConfirmada);
            
                    // Salvar os arquivos atualizados
                    ArquivoUtil.guardarLista("quartos.json", quartos);
                    ArquivoUtil.guardarLista("reservasPendentes.json", reservasPendentes);
            
                    System.out.println("Reserva confirmada com sucesso: " + reservaConfirmada);
                } catch (Exception e) {
                    System.out.println("Erro ao confirmar reserva: " + e.getMessage());
                }
                break;
            

                case 2:
                for(Quarto q : quartosTotais){
                    System.out.println(q);
                }
                System.out.println("Detalhes da Manutenção:");
                System.out.print("ID do Quarto: ");
                int idQuarto = scanner.nextInt();
                System.out.print("Tipo de Manutenção: ");
                scanner.nextLine(); // Limpar buffer
                String tipoManutencao = scanner.nextLine().trim(); // Remover espaços extras

                if (tipoManutencao.isEmpty()) {
                    System.out.println("tipo de manutenção não pode ser vazio");
                    break;
                }

                try {
                    // Carregar os quartos do arquivo JSON
                    List<Quarto> quartos = ArquivoUtil.carregarLista("quartos.json", new TypeReference<List<Quarto>>() {});

                    // Encontrar o quarto pelo ID
                    Quarto quarto = null;
                    for (Quarto room : quartos) {
                        if (room.getId() == idQuarto) {
                            quarto = room;
                            break;
                        }
                    }

                    if (quarto == null) {
                        System.out.println("Quarto não encontrado");
                    } else {
                        // Adicionar uma nova manutenção ao quarto
                        Manutencao manutencao = new Manutencao(quarto.getManutencoes().size() + 1, tipoManutencao);
                        quarto.getManutencoes().add(manutencao);

                        // Alterar o status do quarto para "em manutenção", se não estiver já em manutenção
                        if (!"em manutenção".equals(quarto.getStatus())) {
                            quarto.setStatus("em manutenção");
                        }

                        // Salvar o arquivo atualizado
                        ArquivoUtil.guardarLista("quartos.json", quartos);
                        System.out.println("Manutenção adicionada com sucesso: " + manutencao);
                    }
                } catch (Exception e) {
                    System.out.println("Erro ao adicionar manutenção: " + e.getMessage());
                }
                break;

                case 3:
                        System.out.print("ID da Manutenção para Remover: ");
                        int idManutencao = scanner.nextInt();
                        boolean removido = false;
                    
                        for (Quarto quarto : quartosTotais) {
                            for (Manutencao m : quarto.getManutencoes()) {
                                if (m.getIdManutencao() == idManutencao) {
                                    funcionario.removerManutencao(m, quarto.getManutencoes());
                                    System.out.println("Manutenção removida com sucesso");
                                    removido = true;
                                    break; // interrompe o loop interno
                                }
                            }
                            if (removido) {
                                break; // interrompe o loop externo
                            }
                        }
                    
                        if (!removido) {
                            System.out.println("Manutenção não encontrada");
                        }
                        break;

                case 4: // Procurar Quarto
                procurarQuarto(funcionario, scanner);
                break;

                case 5: // Cancelar Reserva
                cancelarReserva(funcionario, scanner);
                break;

                case 9: // Sair
                    System.out.println("A sair do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        }
        scanner.close();
    }
    private static void procurarQuarto(FuncionarioHotel f, Scanner scanner) {
        int idQuarto = lerNumero(scanner, "Digite o ID do quarto para procurar: ");
        Quarto quartoProcurado = new Quarto(idQuarto, 0, 0, 0, "", "", false);
        f.procurarQuarto(quartoProcurado);
    }
    private static int lerNumero(Scanner scanner, String mensagem) {
        int numero;
        while (true) {
            System.out.print(mensagem);
            try {
                numero = Integer.parseInt(scanner.nextLine());
                break;
            } catch (NumberFormatException e) {
                System.out.println("entrada inválida, por favor, insira um número");
            }
        }
        return numero;
    }
    private static void cancelarReserva(FuncionarioHotel f, Scanner scanner) {
        int idReserva = lerNumero(scanner, "Digite o ID da reserva a ser cancelada: ");
        f.cancelarReserva(idReserva);
    }
}
