package MDS;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
//import java.util.Scanner;
import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.type.TypeReference;

public class FuncionarioHotelImplTest {
    
    @BeforeEach
    void setUp(){
        //List<Reserva> reservasPendentes = ArquivoUtil.carregarLista("reservasPendentesTeste.json", new TypeReference<List<Reserva>>() {});
    
    }
   @Test
    public void ConfirmarReservaTest(){
        List<Reserva> reservasPendentes = ArquivoUtil.carregarLista("reservasPendentesTeste.json", new TypeReference<List<Reserva>>() {});
        if(reservasPendentes.size() == 0){
            System.out.println("não existem reservas pendentes de confirmação");
            return;
        }
       Reserva reservaConfirmada = reservasPendentes.get(0);
        try {
            List<Quarto> quartos = ArquivoUtil.carregarLista("quartosTeste.json", new TypeReference<List<Quarto>>() {});
            Quarto quartoReservado = null;
            for (Quarto room1 : quartos) {
                if (room1.getId() == reservaConfirmada.getIdQuarto()) {
                    quartoReservado = room1;
                    break;
                }
            }
    
            if (quartoReservado == null) {
                System.out.println("Erro: Quarto associado à reserva não encontrado");

            }
            reservaConfirmada.alterarStatus("confirmada");
            for(Reserva r : reservasPendentes){
                if(r.getIdReserva() == reservaConfirmada.getIdReserva()){
                    assertTrue(r.getStatus().equals("confirmada"));
                }
            }
            reservaConfirmada.setId(quartoReservado.getReservas().size() + 1); //quartoReservado.getReservas().size() + 1
            quartoReservado.getReservas().add(reservaConfirmada);
            reservasPendentes.remove(reservaConfirmada);
            ArquivoUtil.guardarLista("quartosTeste.json", quartos);
          //  quartos = ArquivoUtil.carregarLista("quartosTeste.json", new TypeReference<List<Quarto>>() {});
            for(Quarto q : quartos){
                List<Reserva> res = q.getReservas();
                for(Reserva r : res){
                    if(r.getIdReserva() == reservaConfirmada.getIdReserva()){
                        assertTrue(true);
                    }   
                }
            }
            ArquivoUtil.guardarLista("reservasPendentesTeste.json", reservasPendentes);
            List<Reserva> res = ArquivoUtil.carregarLista("reservasPendentesTeste.json", new TypeReference<List<Reserva>>() {});
            assertFalse(res.contains(reservaConfirmada));
            System.out.println("Reserva confirmada com sucesso: " + reservaConfirmada);
            reservaConfirmada.setId(1);
            reservasPendentes.add(reservaConfirmada);
            ArquivoUtil.guardarLista("reservasPendentesTeste.json", reservasPendentes);

        } catch (Exception e) {
            System.out.println("Erro ao confirmar reserva: " + e.getMessage());
        }
    }
@Test
public void adicionarManutençãoTest(){
    Random r = new Random();
    try {
        List<Quarto> quartos = ArquivoUtil.carregarLista("quartosTeste.json", new TypeReference<List<Quarto>>() {});
        Quarto quarto = null;
        // Encontrar o quarto pelo ID
        for(Quarto q : quartos){
            if(q.getId() == 123){
                quarto = q;
            }
        }
   /*      for (Quarto room : quartos) {
            if (room.getId() == quarto.getId()) {
                quarto = room;
                break;
            }
        }*/
            // Adicionar uma nova manutenção ao quarto
            Manutencao manutencao = new Manutencao(quarto.getManutencoes().size() + 1, "testeDaFunc" + Integer.toString(r.nextInt(100000))); //para teste apenas
            quarto.getManutencoes().add(manutencao);

            // Alterar o status do quarto para "em manutenção", se não estiver já em manutenção
            if (!"em manutenção".equals(quarto.getStatus())) {
                quarto.setStatus("em manutenção");
                assertTrue(quarto.getStatus().equals("em manutenção"));
            }

            // guardar o ficheiro
            ArquivoUtil.guardarLista("quartosTeste.json", quartos);
            for(Quarto q : quartos){
                List<Manutencao> man = q.getManutencoes();
                if(man.contains(manutencao)){
                    assertTrue(true);
                }
            }
            System.out.println("Manutenção adicionada com sucesso: " + manutencao);
            quarto.setStatus("disponivel");
        
    } catch (Exception e) {
        System.out.println("Erro ao adicionar manutenção: " + e.getMessage());
    }
}

}
