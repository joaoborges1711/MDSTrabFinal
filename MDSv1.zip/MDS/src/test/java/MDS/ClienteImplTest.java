package MDS;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ClienteImplTest {

    private Cliente cliente;
    private List<Quarto> listaQuartos;
    private List<Reserva> reservasPendentes;


    @BeforeEach
public void setUp() {
    System.out.println("Executando o método setUp()...");  // Adiciona um log para verificar
    cliente = new Cliente(1, "João", "123456789", LocalDate.of(1990, 1, 1));
    listaQuartos = new ArrayList<>();
    listaQuartos.add(new Quarto(1, 2, 3, 4, "mar", "ocupado", true));
    listaQuartos.add(new Quarto(2, 3, 4, 5, "predio", "disponível", false));
    listaQuartos.add(new Quarto(3, 4, 4, 4, "mar", "em manutenção", false));
    listaQuartos.add(new Quarto(4, 5, 6, 2, "sem vista", "em manutenção", true));

    // Inicializar reservasPendentes
    reservasPendentes = new ArrayList<>();
}

    
    

    @Test
    public void testVerificarDisponibilidadeQuartoDisponivel() throws ParseException {
        // Criar um quarto de teste
        Quarto quartoTeste = new Quarto(1, 2, 1, 1, "cidade", "disponível", false);
        listaQuartos.add(quartoTeste);

        // Definir datas para o teste
        String dataEntrada = "2025-02-01";
        String dataSaida = "2025-02-05";

        boolean disponibilidade = quartoTeste.isDisponivel(
            new SimpleDateFormat("yyyy-MM-dd").parse(dataEntrada),
            new SimpleDateFormat("yyyy-MM-dd").parse(dataSaida)
        );

        assertTrue(disponibilidade);
    }

    @Test
    public void testProcurarQuartoDisponivel() {
      //  Quarto quartoTeste = new Quarto(listaQuartos.size()+1, 2, 1, 1, "cidade", "disponível", false);
       // listaQuartos.add(quartoTeste);
    
        // Modificando a entrada simulada para garantir que o ID do quarto seja lido corretamente
        String inputSimulado = "1\n";  // Simula a entrada do ID do quarto
        Scanner scanner = new Scanner(inputSimulado);
        ByteArrayOutputStream saidaCapturada = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(saidaCapturada));
    
        try {
            // Chama o método que você está testando
            ClienteImpl.procurarQuarto(cliente, scanner);
            System.setOut(originalOut);
    
            // Captura a saída do método e verifica se contém a mensagem esperada
            String saida = saidaCapturada.toString();
            System.out.println("Saída capturada: " + saida);  // Para depuração, veja a saída exata
    
            // Verificar se a saída contém a mensagem "Quartos disponíveis:" e a representação do quarto
          //  assertTrue(saida.contains("Quartos disponíveis:"));
            assertTrue(saida.contains("Quarto{id=1, capacidade=2, nCamas=3, nWC=4, tipoVista='mar', status='ocupado', temCozinha=true}"));
        } finally {
            System.setOut(originalOut);
        }
    }
    
    


@Test
public void testFazerReservaComSucesso() throws ParseException {
    Quarto quartoTeste = new Quarto(listaQuartos.size()+1, 2, 1, 1, "cidade", "disponível", false);
    listaQuartos.add(quartoTeste);
    String dataEntrada = "2025-02-01";
    String dataSaida = "2025-02-05";
    Reserva novaReserva = new Reserva(reservasPendentes.size() + 1, 
                                      new SimpleDateFormat("yyyy-MM-dd").parse(dataEntrada), 
                                      new SimpleDateFormat("yyyy-MM-dd").parse(dataSaida), 
                                      "pendente", quartoTeste.getId(), cliente.getIdPessoa());
    reservasPendentes.add(novaReserva);
    ArquivoUtil.guardarLista("reservasPendentesTeste.json", reservasPendentes);

    // Carregar a lista do arquivo correto
    List<Reserva> reservasPendentesTeste = ArquivoUtil.carregarLista("reservasPendentesTeste.json", new TypeReference<List<Reserva>>() {});

    // Verificar se a reserva foi adicionada corretamente à lista
    assertTrue(reservasPendentes.contains(novaReserva));
    assertTrue(reservasPendentesTeste.contains(novaReserva));
    assertTrue(!reservasPendentesTeste.isEmpty());  // Verificar que a lista não está vazia
}


@Test
public void testConsultarReserva() {
    String inputSimulado = "2\n";
    Scanner scanner = new Scanner(inputSimulado);
    ByteArrayOutputStream saidaCapturada = new ByteArrayOutputStream();
    PrintStream originalOut = System.out;
    System.setOut(new PrintStream(saidaCapturada));

    try {
        ClienteImpl.consultarReserva(cliente, scanner);
        List<Reserva> reservasPendentesTeste = ArquivoUtil.carregarLista("reservasPendentes.json", new TypeReference<List<Reserva>>() {});

        Reserva rr = null;  
        for (Reserva r : reservasPendentesTeste) {
            if (r.getIdReserva() == Integer.parseInt(inputSimulado.trim())) {
                rr = r; 
                break;
            }
        }
        if (rr == null) {
            fail("Reserva com ID " + inputSimulado.trim() + " não encontrada.");
        }

        System.setOut(originalOut);
        String saida = saidaCapturada.toString();
        System.out.println("Saída capturada: " + saida);
        assertTrue(saida.contains("Reserva{idReserva=" + rr.getIdReserva() + 
                                  ", dataEntrada=" + rr.getDataEntrada() + 
                                  ", dataSaida=" + rr.getDataSaida() + 
                                  ", status='" + rr.getStatus() + "'}"), 
                   "A saída não contém os detalhes da reserva esperada.");
    } finally {
        System.setOut(originalOut);
    }
}

@Test
public void testCancelarReserva() {
    // Carregar a lista de reservas pendentes
    List<Reserva> reservasPendentes = ArquivoUtil.carregarLista("reservasPendentesTeste.json", new TypeReference<List<Reserva>>() {});
    
    // Criar um cliente para o teste
    //Cliente cliente = new Cliente(1, "João", "123456789", LocalDate.of(1990, 1, 1));
    
    // Simular a entrada do usuário para cancelar a reserva
    String inputSimulado = "1\n"; // ID da reserva a ser cancelada
    Scanner scanner = new Scanner(inputSimulado);

    // Redirecionar a saída padrão para capturar a saída do método
    ByteArrayOutputStream saidaCapturada = new ByteArrayOutputStream();
    PrintStream originalOut = System.out;
    System.setOut(new PrintStream(saidaCapturada));

    try {
        // Buscar a reserva com o ID informado
        int idReserva = Integer.parseInt(inputSimulado.trim());
        Reserva reservaTeste = reservasPendentes.stream()
                                                .filter(r -> r.getIdReserva() == idReserva)
                                                .findFirst()
                                                .orElse(null);

        System.out.println(reservaTeste);
        if (reservaTeste == null) {
            fail("Reserva com ID " + idReserva + " não encontrada.");
        }

        cancelarReserva(idReserva);

        // Recarregar a lista de reservas após o cancelamento
        reservasPendentes = ArquivoUtil.carregarLista("reservasPendentesTeste.json", new TypeReference<List<Reserva>>() {});

        // Verificar se a reserva foi removida
        boolean reservaAindaExiste = reservasPendentes.stream()
                                                      .anyMatch(r -> r.getIdReserva() == idReserva);
        assertFalse(reservaAindaExiste, "A reserva não foi cancelada corretamente.");

        // Restaurar a saída padrão
        System.setOut(originalOut);

        // Verificar a saída capturada
        String saida = saidaCapturada.toString();
        System.out.println("Saída capturada: " + saida);
        //assertTrue(saida.contains("Reserva com ID 1 cancelada com sucesso."),
                 //  "A saída não contém a mensagem de sucesso esperada.");
                 reservasPendentes.add(reservaTeste);
                 ArquivoUtil.guardarLista("reservasPendentesTeste.json", reservasPendentes);
    } finally {
        // Garantir que a saída padrão seja restaurada
        System.setOut(originalOut);
        scanner.close();
    }
}

public void cancelarReserva(int idReserva) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            File arquivo = new File("reservasPendentesTeste.json");
            if (arquivo.exists()) {
                List<Reserva> reservas = objectMapper.readValue(arquivo, new TypeReference<List<Reserva>>() {});
                boolean reservaRemovida = reservas.removeIf(reserva -> reserva.getIdReserva() == idReserva);
    
                if (reservaRemovida) {
                    objectMapper.writeValue(arquivo, reservas);
                    System.out.println("Reserva com ID " + idReserva + " foi cancelada com sucesso.");
                } else {
                    System.out.println("Reserva com ID " + idReserva + " não encontrada.");
                }
            } else {
                System.out.println("Ficheiro de reservasPendentes.json não encontrado.");
            }
        } catch (IOException e) {
            System.out.println("erro ao processar o ficheiro de reservas: " + e.getMessage());
        }
    }
}
