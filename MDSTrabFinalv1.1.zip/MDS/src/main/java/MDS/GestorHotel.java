package MDS;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GestorHotel extends Person implements interfaceAdmin {

    private List<Quarto> quartosGeridos;

    public GestorHotel(int idPessoa, String nome, String BI, LocalDate dataNascimento) {
        super(idPessoa, nome, BI, dataNascimento);
        this.quartosGeridos = new ArrayList<>();
    }

    public Quarto consultarQuarto(int idQuarto, List<Quarto> list) {
        for (Quarto quarto : list) {
            if (quarto.getId() == idQuarto) {
                return quarto;
            }
        }
        return null;
    }

    public List<Quarto> consultarQuartosDisponiveis(List<Quarto> totalQuartos, Date dataEntrada, Date dataSaida) {
        List<Quarto> quartosDisponiveis = new ArrayList<>();
        for (Quarto q : totalQuartos) {
            if (q.isDisponivel(dataEntrada, dataSaida)) {
                quartosDisponiveis.add(q);
            }
        }
        return quartosDisponiveis;
    }

    public List<Quarto> listarQuartos() {
        return new ArrayList<>(quartosGeridos);
    }

    @Override
    public String toString() {
        return "GestorHotel{" +
                "idPessoa=" + getIdPessoa() +
                ", BI=" + getBI() +
                ", nome='" + getNome() + '\'' +
                ", quartosGeridos=" + quartosGeridos.size() +
                '}';
    }

    @Override
    public void verificarManutencao(Manutencao m) {
        System.out.println(m.toString());
    }

    @Override
    public void confirmarReserva(List<Reserva> reservasPendentes, int idReserva) {
        for (Reserva r : reservasPendentes) {
            if (r.getIdReserva() == idReserva) {
                r.alterarStatus("confirmada");
                return;
            }
        }
        System.out.println("reserva não encontrada");
    }

    @Override
    public void adicionarManutencao(Manutencao manutencao, List<Manutencao> listaManutencoes) {
        for (Manutencao m : listaManutencoes) {
            if (m.getIdManutencao() == manutencao.getIdManutencao()) {
                System.out.println("essa manutenção já foi adicionada");
                return;
            }
        }
        listaManutencoes.add(manutencao);
    }

    @Override
    public void removerManutencao(Manutencao m, List<Manutencao> listaManutencoes) {
        listaManutencoes.removeIf(man -> man.getIdManutencao() == m.getIdManutencao());
    }

    public List<Quarto> carregarListaDeReservas() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            File arquivo = new File("reservas.json");
            if (arquivo.exists()) {
                return objectMapper.readValue(arquivo, new TypeReference<List<Quarto>>() {
                });
            }
        } catch (IOException e) {
            System.out.println("erro ao carregar lista" + e.getMessage());
        }
        return new ArrayList<>();
    }

    public void guardarListaDeReservas(List<Reserva> listaReservas) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            objectMapper.writeValue(new File("reservas.json"), listaReservas);
        } catch (IOException e) {
            System.out.println("erro ao carregar lista: " + e.getMessage());
        }
    }

    @Override
    public void modificarQuarto(int id, int capacidade, int nCamas, int nWC, String tipoVista, String status,
            boolean temCozinha) {
        throw new UnsupportedOperationException("não é suposto implementar");
    }

    @Override
    public void adicionarQuarto(Quarto quarto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("não é suposto implementar'");
    }

    @Override
    public void removerQuarto(Quarto quarto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("não é suposto implementar");
    }
}
