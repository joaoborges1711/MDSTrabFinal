package MDS;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class GestorSistemaImplTest {

    private List<Quarto> listaQuartos;

    @BeforeEach
    public void setup() {
        listaQuartos = ArquivoUtil.carregarLista("quartosTeste.json", new TypeReference<List<Quarto>>() {});
    }

    public void guardarListaDeQuartos() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            objectMapper.writeValue(new File("quartosTeste.json"), listaQuartos);
        } catch (IOException e) {
            System.out.println("Erro ao guardar lista: " + e.getMessage());
        }
    }
    public void adicionarQuarto(Quarto quarto) {
        if (!listaQuartos.contains(quarto)) {
            listaQuartos.add(quarto);
            guardarListaDeQuartos();
            System.out.println("Quarto adicionado com sucesso: " + quarto);
        } else {
            System.out.println("esse quarto já existe na lista");
        }
    }

    public void removerQuarto(Quarto quarto) {
        if (listaQuartos.remove(quarto)) {
            guardarListaDeQuartos();
            System.out.println("quarto removido com sucesso: " + quarto);
        } else {
            System.out.println("quarto não encontrado na lista");
        }
    }

    @Test
    public void testAdicionarQuarto() {
       // GestorSistema gestorSistema = new GestorSistema(0, null, null, null);
        Quarto novoQuarto = new Quarto(listaQuartos.size() + 1, 40, 2, 1, "Vista Montanha", "disponivel", false);
        adicionarQuarto(novoQuarto);
        List<Quarto> listaAtualizada = ArquivoUtil.carregarLista("quartosTeste.json", new TypeReference<List<Quarto>>() {});
        System.out.println(listaAtualizada);
        assertTrue(listaAtualizada.stream().anyMatch(q -> q.getId() == novoQuarto.getId()), "O novo quarto não foi adicionado");
        removerQuarto(novoQuarto);
        //para fins de teste, manter o ficheiro pequeno e manter a persistencia
    }
@Test
public void testRemoverQuarto(){
    Quarto novoQuarto = new Quarto(listaQuartos.size() + 1, 40, 2, 1, "Vista Montanha", "disponivel", false);
    listaQuartos.add(novoQuarto);
    removerQuarto(novoQuarto);
    List<Quarto> listaAtualizada = ArquivoUtil.carregarLista("quartosTeste.json", new TypeReference<List<Quarto>>() {});
    System.out.println(listaAtualizada);
    assertFalse(listaAtualizada.stream().anyMatch(q -> q.getId() == novoQuarto.getId()), "O novo quarto não foi adicionado");
    adicionarQuarto(novoQuarto); //para fins de teste, manter o ficheiro pequeno e manter a persistencia
}




}

